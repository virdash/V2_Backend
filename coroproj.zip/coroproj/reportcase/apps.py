from django.apps import AppConfig


class ReportcaseConfig(AppConfig):
    name = 'reportcase'
